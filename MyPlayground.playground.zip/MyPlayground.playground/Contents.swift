import UIKit

var str = "Hello, playground"

class University
{
    
    var classnumber: Int;
    var studentName: String ;
    var TeacherName : String ;
    var  Subject : String;
    
    init(classnumber : Int ,student: String , Teacher : String ,Subject: String)
        
        {
        self.classnumber=classnumber
        self.studentName=studentName
        self.TeacherName=TeacherName
        self.Subject=Subject
    }
    
}
let student1:  University( classnumber: 1 , student:      )

